<!DOCTYPE HTML >
<html>
<head>
<title>Untitled Document</title>
<meta http-equiv="Content-Type" content="text/html; charset=iso-8859-1">
</head>
<script language="javascript">
    
    function clearinputText1() {
    document.details.username.value= "";
	}
	function clearinputText2() {
	document.details.password.value= "";
    }
	function clearinputText3() {
	document.details1.username1.value= "";
    }
	function clearinputText4() {
	document.details1.password1.value= "";
    }
	function clearinputText5() {
	document.details1.password2.value= "";
    }
	function clearinputText6() {
	document.details2.username4.value= "";
    }
	
	function validate1(){
	var emailRegEx1 = /^[A-Z0-9._%+-]+@[A-Z0-9.-]+\.[A-Z]{2,4}$/i;
	if(document.details.username.value=="" || document.details.password.value=="")
	{
	alert("  Please Fill the fields  ");
	details.username.focus();
	return false;
	}
	else if (document.details.username.value.search(emailRegEx1) == -1) 
	{
    alert("  Please Enter a Valid Email Address  ");
    document.details.password.value= "";
	details.username.focus();
    return false;
    }
	return true;
	}
	
	function validate3(){
	var emailRegEx2 = /^[A-Z0-9._%+-]+@[A-Z0-9.-]+\.[A-Z]{2,4}$/i;
	if(document.details2.username4.value=="")
	{
	alert("  Please Enter the UserName  ");
	details2.username4.focus();
	return false;
	}
	else if (document.details2.username4.value.search(emailRegEx2) == -1) 
	{
    alert("  Please Enter a Valid Email Address  ");
    details2.username4.focus();
    return false;
    }
	return true;
	}
	
	function validate2(){
	var emailRegEx = /^[A-Z0-9._%+-]+@[A-Z0-9.-]+\.[A-Z]{2,4}$/i;
     
	if(document.details1.username1.value=="" || document.details1.password1.value=="" || document.details1.password2.value=="")
	{
	alert("  Please Complete the fields  ");
	document.details1.password1.value= "";
	document.details1.password2.value= "";
	details1.username1.focus();
	return false;
	}
	else if (document.details1.username1.value.search(emailRegEx) == -1) 
	{
    alert("  Please Enter a Valid Email Address  ");
    document.details1.password1.value= "";
	document.details1.password2.value= "";
	details1.username1.focus();
    return false;
    }
	else if(document.details1.password1.value.length <6 )
	{
	alert("  Passwords Must Be Between 6-14 Characters Long  ");
	document.details1.password2.value= "";
	details1.password1.focus();
	return false; 
    }
	else if( document.details1.password1.value != document.details1.password2.value )
	{
	alert(" Please Enter Same Passwords  ");
	document.details1.password2.value= "";
	details1.password1.focus();
	return false;
	}
	return true;
	}
	</script>
<body leftmargin=0 topmargin=0 marginwidth=0 marginheight=0 >
<div id="header1" style="width:auto; position:relative; height:70px; padding-left:10px; padding-top:5px; padding-bottom:10px; 
border-bottom-style:hidden; border-radius:2px;background-image:url(header_stars.png); background-repeat:repeat-x; background-color:#00A9FF; ">
<label style=" display:block; position:relative; width:auto; font-family:Lucia Grande; font-size:18px; height:25px; font-weight:bolder; 
border:1px hidden #000000; border-radius:2px;">
<center><img src="Datavo Logo yelp.png" height="45px" width="170px"></center><br>
</label>
<label style=" display:block; position:relative; float:left; width:100%; visibility:hidden; font-family:Lucia Grande; font-size:18px; height:30px; font-weight:bolder; background-color:#D7D7D7; border:1px hidden #000000; border-radius:2px;"></label>
<label style="display:block; padding-left:32%; position:relative; width:auto; font-family:Lucia Grande; font-size:18px; height:auto; font-weight:bolder; border:1px hidden #000000; border-radius:2px;">
<ul id="menu" style="display:block;  position:relative; width:auto; color:#FFFFFF; font-family:Times New Roman; font-weight:600; 
font-size:16px;">
<a href="index.php"><li id="home" style="display:inline-block; color:#FFFFFF; float:left; ">Home&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;</li></a>
<a href="aboutus.php"><li id="about" style="display:inline-block; color:#FFFFFF; float:left;">About Us&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;</li></a>
<a href="login_review.php"><li id="review" style="display:inline-block; color:#FFFFFF; float:left;">Write a Review&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;</li></a>
<a href="events.php"><li id="events" style="display:inline-block; color:#FFFFFF; float:left;">Events</li></a>
</ul>
</label>
</div>
