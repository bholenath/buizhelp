<?php
include("db.php");
$insert1="update users set verification = 'verified' where username='$_POST['hid2'];'";
$result1=mysql_query($insert1);
if($result1)
{
echo "<script>alert(' Account Verified Successfully Log In to Continue ');</script>";
echo "<script>location.href='login.php';</script>";
}
else
die('Could not connect: ' . mysql_error());
?>
