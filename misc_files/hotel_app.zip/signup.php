<?php
include("header1.php");
?>
<hr width="100%" style="height:1;"></hr>
<div style=" padding-left:75px; padding-right:75px; width:auto; height:auto;">
<div style="display:block; padding-left:35px; padding-right:35px; position:relative; padding-top:25px; padding-bottom:25px; width:auto; height:300px;  border: 1px hidden #FFD735; background-color:#ffffff; border-radius:5px;">
<center>
<font style="color:#C41200; font-size:21px; font-weight:bolder; ">Sign Up for Dovato</font><br>
<font style="color:#000000; font-size:14px; font-weight:bold; ">Connect with great local businesses.</font>
<br><br>
<form name="details1" method="POST" action="entering.php" target="_self" onSubmit="return validate2()">
<label style=" display:block;  width:30%; font-family:Times New Roman; font-size:14px; height:23px; font-weight:bolder; 
background-color:#ffffff; border:1px solid #BBBBBB; border-radius:2px;">
<input type="text" name="username1" placeholder="UserName/E-mail Id" maxlength="64" onfocus="clearinputText3();" 
style="border:1px hidden #000000; text-align:center; padding-top:2px; font-size:14px; font-family:Times New Roman; width:auto; border-radius:1px; background-color:#ffffff;">
</label>
<font style="color:#3B65A7; font-size:11px; font-family:Times New Roman;"> * UserName must be Your Mail Id  </font>
<label style=" display:block;  width:0; font-family:Arial; font-size:14px; height:7px; font-weight:bolder; border:1px hidden #007eff;">
</label>
<label style=" display:block;  width:30%; font-family:Times New Roman; font-size:14px; height:23px; font-weight:bolder; 
background-color:#ffffff; border:1px solid #BBBBBB; border-radius:2px;">
<input type="password" name="password1" placeholder="Choose your Password" maxlength="14" onfocus="clearinputText4();" 
style="border:1px hidden #000000; text-align:center; font-size:14px; font-family:Times New Roman; padding-top:2px; width:auto; border-radius:1px; background-color:#ffffff;">
</label>
<br>
<label style=" display:block;  width:30%; font-family:Times New Roman; font-size:14px; height:23px; font-weight:bolder; 
background-color:#ffffff; border:1px solid #BBBBBB; border-radius:2px;">
<input type="password" name="password2" placeholder="Confirm your Password" maxlength="14" onfocus="clearinputText5();" 
style="border:1px hidden #000000; text-align:center;  font-size:14px; padding-top:2px; font-family:Times New Roman; width:auto; border-radius:1px; background-color:#ffffff;">
</label>
<font style="color:#3B65A7; font-size:11px; font-family:Times New Roman;"> * Password Must Be Between 6-14 Characters Long </font>
<label style=" display:block;  width:0; font-family:Arial; font-size:14px; height:15px; font-weight:bolder; 
 border:1px hidden #007eff;">
</label>
<label style=" display:block;  width:auto;   font-family:Times New Roman; font-size:14px; height:35px;">
<font style="color:#000000;">By creating an account, you agree to Dovato�s Terms of Service and Privacy Policy .</font>
</label>
<label style=" display:block;  width:72%; font-family:Arial; font-size:14px; height:auto; font-weight:bolder;">
<input type="submit" name="submit" value="Sign Up" style="background-color:#DD0D04; cursor:pointer; color:#ffffff; font-family:Lucia Grande; font-size:14px; font-weight:bolder; border-radius:2px; border:1px hidden #000000; height:30px; width:42%;">
</label>
<label style=" display:block;  width:130px; font-family:Arial; font-size:14px; height:10px; font-weight:bolder; 
 border:1px hidden #007eff;">
</label>
<label style=" display:block; width:42%; font-family:Times New Roman; font-size:13px; height:35px;">
<font style="color:#3B65A7;">Already on Dovato?<a href="login.php"> Log in</a></font>
</label>
</form>
</center>
</div>
</div>
<hr width="100%" style="height:1;"></hr>
<?php
include("footer1.php");
?>