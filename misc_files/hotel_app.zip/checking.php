<?php
session_start();
include("db.php");
$name=trim($_REQUEST["username"]);
$pass=trim($_REQUEST["password"]);
if($name=="")
 {
header("location:login.php?err=Please enter user name");
die();
}
else if($pass=="")
 {
header("location:login.php?err=Please enter password");
die();
}
$sql="select * from users where username='$name' and password='$pass' ";
$result=mysql_query($sql,$con);
$row = mysql_fetch_array($result);
$num_rows = mysql_num_rows($result);
if($num_rows == 0)
{
echo "<script>alert(' Check your UserName or Password  ');</script>";
echo "<script>location.href='login.php?err=Invalid Username or Password!';</script>";
}
else if($row['verification'] != 'verified')
{
echo "<script>alert(' Please First Verify Your Account ');</script>";
echo "<script>location.href='login.php?err=Account Not Verified!';</script>";
}
else
{
$_SESSION['client']=$name;
header("Location:dashboard.php");
exit();
}
?>
