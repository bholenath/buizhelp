<?php
include("db.php");
$insert2="update users set verification = 'verified' , password = '$_POST['hid'];' where username='$_POST['hid1'];'";
$result2=mysql_query($insert2);
if($result2)
{
echo "<script>alert(' Password Successfully Changed ');</script>";
echo "<script>location.href='login.php';</script>";
}
else
die('Could not connect: ' . mysql_error());
?>