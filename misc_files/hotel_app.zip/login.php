<?php
include("header1.php");
?>
<style type="text/css">
<!--
a:link {
	text-decoration: none;
}
a:visited {
	text-decoration: none;
}
a:hover {
	text-decoration: none;
}
a:active {
	text-decoration: none;
}
-->
</style>
<hr width="100%" style="height:1;"></hr>
<div style=" padding-left:75px; padding-right:75px; width:auto; height:auto;">
<div style="display:block; padding-left:35px; padding-right:35px; position:relative; padding-top:25px; padding-bottom:25px; width:auto; height:300px;  border: 1px solid #FFD735; background-color:#FDF7E1; border-radius:5px;">
<div style="width:49%; float:left; display:block;  height:auto; position:relative;  "> 
<font style="color:#C41200; font-size:21px; font-weight:bolder; ">Log In</font><br>
<font style="color:#000000; font-size:12px; font-weight:600px; ">Please Enter a valid Username and Password to Log In</font>
<br><br><br>
<form name="details" method="post" action="checking.php" target="_self"; onSubmit="return validate1();">
<label style=" display:block; float:left; width:130px; font-family:Arial; font-size:14px; height:35px; font-weight:bolder;">
<font style="color:#C41200;">UserName</font>
</label>
<label style=" display:block; float:left; width:42%; font-family:Arial; font-size:14px; height:23px; font-weight:bolder; 
background-color:#ffffff; border:1px solid #007eff; border-radius:2px;">
<input type="text" name="username"  placeholder="Enter your UserName" maxlength="64" onfocus="clearinputText1();" 
style="border:1px hidden #000000;  padding-top:2px; width:auto; border-radius:1px; background-color:#ffffff;">
</label>
<br><br>
<label style=" display:block; float:left; width:130px; font-family:Arial; font-size:14px; height:35px; font-weight:bolder;">
<font style="color:#C41200;">Password</font>
</label>
<label style=" display:block; float:left; width:42%; font-family:Arial; font-size:14px; height:23px; font-weight:bolder; 
background-color:#ffffff; border:1px solid #007eff; border-radius:2px;">
<input type="password" name="password"  placeholder="Enter your Password" maxlength="14" onfocus="clearinputText2();" 
style="border:1px hidden #000000;  padding-top:2px; width:auto; border-radius:1px; background-color:#ffffff;">
</label>
<br><br>
<label style=" display:block; float:left; width:130px; font-family:Arial; font-size:14px; height:23px; font-weight:bolder; 
 border:1px hidden #007eff;">
</label>
<label style=" display:block; float:left; width:42%; font-family:Times New Roman; font-size:11px; height:35px;">
<font style="color:#3B65A7;"><a href="forgot.php">Forgot Your Password ?</a></font>
</label>
<label style=" display:block; float:right; width:40%; font-family:Arial; font-size:14px; height:auto; font-weight:bolder;">
<input type="submit" name="submit" value="Log In" style="background-color:#DD0D04; cursor:pointer; color:#ffffff; font-family:Lucia Grande; font-size:14px; font-weight:bolder; border-radius:2px; border:1px hidden #000000; height:30px; width:auto;">
</label>
<br><br><br><br>
<label style=" display:block; float:left; width:0; font-family:Arial; font-size:14px; height:23px; font-weight:bolder; 
 border:1px hidden #007eff;">
</label>
<label style=" display:block;  width:auto; text-align:justify; font-family:Times New Roman; font-size:14px; height:35px;">
<font style="color:#000000;">By logging in you agree to Dovato's Terms of Service<br> and Privacy Policy.</font>
</label>
</form>
</div>
<div style="width:48%; float:left; display:block; height:auto; position:relative;">
<label style=" display:block; float:left; width:1px; padding-right:40px; font-family:Arial; font-size:14px; height:auto; font-weight:bolder; 
 border:1px hidden #007eff;">
<hr width="1px" style="height:300px;"></hr>
</label>
<center><font style="color:#C41200; font-size:21px; font-weight:bolder; ">No Account Yet ?</font><br>
<font style="color:#000000; font-size:14px; font-weight:600px; ">That's okay, we still love you.</font><br><br>
<a href="signup.php" target="_self"><input type="button" name="submit" value="Sign Up" style="background-color:#DA0E03; color:#ffffff; font-family:Lucia Grande; font-size:14px; cursor:pointer; font-weight:bolder; border-radius:2px; border:1px hidden #000000; height:30px; width:auto;"></a><br><br>
<font style="color:#000000; font-size:14px; font-weight:600px; ">Dovato is the fun and easy way to find, review and talk about what's great - and not so great - in your local area. It's about real people giving their honest and personal opinions on everything from restaurants and spas to coffee shops and bars.</font
</center>
</div>
</div>
</div>
<hr width="100%" style="height:1px;"></hr>
<?php
include("footer1.php");
?>