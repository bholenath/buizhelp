<!DOCTYPE HTML>
<html xmlns="http://www.w3.org/1999/xhtml">
<head>
<meta http-equiv="Content-Type" content="text/html; charset=utf-8" />
<title>Main Site</title>

<style type="text/css">
<!--
a:link {
	text-decoration: none;
}
a:visited {
	text-decoration: none;
}
a:hover {
	text-decoration: none;
}
a:active {
	text-decoration: none;
}
-->

.button:hover {
	background-color:#f69125;
	color:#000000;
}

submit:focus,select:focus{
 
 -webkit-box-shadow:0 0 10px #007eff;
 -moz-box-shadow:0 0 10px #007eff;
 box-shadow:0 0 10px #007eff;
}
</style>
</head>
    <script language="javascript">
    
    function clearinputText() {
    document.frm.find1.value= "";
    }
	
	function clearinputText0() {
    document.frm.place.value= "";
    }
	
	function validate(){
	if(document.frm.find1.value=="" && document.frm.place.value=="")
	{
	alert("  Please fill atleast One of the field  ");
	frm.find1.focus();
	return false;
	}
	return true;
	}
	
	/*window.onload = function image()
	{ 
	img.src = "new_burst_loader_big.gif";
	}*/
	
    </script>
	<body leftmargin=0 topmargin=0 marginwidth=0 marginheight=0 >
	  <form  method="post" action="check.php" name="frm" id="frm" target="_blank" onSubmit="return validate();">
		<div id="header" style="width:auto; height:62px; padding-left:10px; padding-top:18px;   border-bottom-style:hidden; border-radius:2px; 
		background-image:url(header_stars.png); background-repeat:repeat-x; background-color:#00A9FF; ">
		 <label style=" display:block; float:left; width:auto; font-family:Lucia Grande; font-size:18px; height:25px; font-weight:bolder; 
		 border:1px hidden #000000; border-radius:2px;">
		  <img src="Datavo Logo yelp.png" height="45px" width="170px">
		 </label>
		 <label style=" display:block; float:left; width:5%; visibility:hidden; font-family:Lucia Grande; font-size:18px; height:25px; font-weight:bolder; 
		 background-color:#D7D7D7; border:1px hidden #000000; border-radius:2px;">
		 </label>
		 <label style=" display:block; float:left; width:25%; font-family:Lucia Grande; font-size:18px; height:25px; font-weight:bolder; 
		 background-color:#D7D7D7; border:1px hidden #000000; border-radius:2px;">&nbsp;Find
		  <input type="text" name="find1"  placeholder="Restaurant,Hotel,Dhaba etc." maxlength="64" onfocus="clearinputText();" 
		  style="border:1px hidden #000000; width:80%; border-radius:1px; background-color:#D7D7D7;">
		 </label>
		 <label style=" display:block; float:left; width:2%; visibility:hidden; font-family:Lucia Grande; font-size:18px; height:25px; font-weight:bolder; 
		 background-color:#D7D7D7; border:1px hidden #000000; border-radius:2px;">
		 </label>
		 <label style=" display:block; float:left; width:25%; font-family:Lucia Grande; font-size:18px; height:25px; font-weight:bolder; 
		 background-color:#D7D7D7; border:1px hidden #000000; border-radius:2px;">&nbsp;Near
		  <input type="text" name="place"  placeholder="Dehradun,India" maxlength="64" onfocus="clearinputText0();" 
		  style="border:1px hidden #000000; width:80%; border-radius:1px; background-color:#D7D7D7;">
		 </label>&nbsp;&nbsp;&nbsp;&nbsp;
		 <label style=" display:block; float:left; width:1%; visibility:hidden; font-family:Lucia Grande; font-size:18px; height:25px; font-weight:bolder; 
		 background-color:#D7D7D7; border:1px hidden #000000; border-radius:2px;">
		 </label>
		 <label style=" display:block; float:left; width:auto; font-family:Lucia Grande; font-size:18px; height:25px; font-weight:bolder; 
		 background-color:#D7D7D7; border:1px hidden #000000; border-radius:2px;">
		  <input type="submit" name="submit" value="Submit" style="background-color:#810000; cursor:pointer; color:#CACACA; font-family:Lucia Grande; font-size:14px; font-weight:bolder; border-radius:2px; border:1px hidden #000000; height:25px; width:auto;">
		  </form>
		 </label>
<label style=" display:block; float:left; width:2%; visibility:hidden; font-family:Lucia Grande; font-size:18px; height:25px; font-weight:bolder; 
background-color:#D7D7D7; border:1px hidden #000000; border-radius:2px;">
</label>
<label style=" display:block; float:right; padding-right:42px; width:auto; font-family:Lucia Grande; font-size:18px; height:25px; font-weight:bolder; 
 border:1px hidden #000000; border-radius:2px;">
<a href="signup.php" target="_self"><input type="button" name="submit" value="Sign Up" style="background-color:#810000; color:#CACACA; font-family:Lucia Grande; 
font-size:14px; cursor:pointer; font-weight:bolder; border-radius:2px; border:1px hidden #000000; height:25px; width:auto;">
</a>
</label>
<br>
<ul id="menu" style="display:block; color:#FFFFFF; font-family:Times New Roman; font-weight:600; font-size:16px; padding-left:21.8%;">
<a href="index.php"><li id="home"  style="display:inline-block; color:#FFFFFF; float:left; ">Home&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;</li></a>
<a href="aboutus.php"><li id="about" style="display:inline-block; color:#FFFFFF; float:left;">About Us&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;</li></a>
<a href="login_review.php"><li id="review" style="display:inline-block; color:#FFFFFF; float:left;">Write a Review&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;</li></a>
<a href="events.php"><li id="events" style="display:inline-block; color:#FFFFFF; float:left;">Events</li></a>
<a href="login.php" target="_self"><li id="login" style="display:inline-block; color:#FFFFFF; padding-right:52px; float:right;">Log In</li></a> 
</ul>
</div>
