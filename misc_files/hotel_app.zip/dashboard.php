<?php
session_start();
include("db.php");
include("header1.php");
if (isset($_SESSION['client'])){
$uname = $_SESSION['client'];
}
$sql="select date , time from users where username='$uname'";
$result=mysql_query($sql,$con);
$row = mysql_fetch_array($result);
$date1 = $row['date'];
$time1 = $row['time'];
date_default_timezone_set('Asia/Calcutta');
$date = date('d-m-Y');
$time = date('H:i:s');
$insert3="update users set date = '$date' , time = '$time' where username='$uname'";
$result3=mysql_query($insert3);
if($result3)
{
}
else
die('Could not connect: ' . mysql_error());
?>
<hr width="100%" style="height:1;"></hr>
<label style="float:left; width:auto; height:30px; padding-top:5px; position:relative; color:#3B65A7; font-family:Times New Roman; font-size:13px; ">
&nbsp;&nbsp;Welcome :&nbsp;&nbsp;<?php echo $uname;  ?>&nbsp;&nbsp;&nbsp;Last Login :&nbsp;&nbsp;
<?php echo $date1;?>&nbsp;&nbsp;<?php echo $time1; ?>
</label>
<label style=" width:auto; height:auto; float:right; position:relative; ">
<a href="profile.php" target="_self"><input type="button" name="submit" value="Complete Your Profile" style="background-color:#DA0E03; color:#ffffff; font-family:Lucia Grande; float:right; margin-right:4%; font-size:14px; cursor:pointer; font-weight:bolder; 
border-radius:2px; border:1px hidden #000000; height:30px; width:auto;">
</a>
</label>

<br><br>

<hr width="100%" style="height:1;"></hr>
<?php
include("footer1.php");
?>