<?php
require_once('/phpmail/class.phpmailer.php');
require_once('/phpmail/class.smtp.php');
include("db.php");
$uname=$_POST['username4'];
$sql="select * from users where username='$uname'";
$result5=mysql_query($sql,$con);
$num_rows1=mysql_num_rows($result5);
if($num_rows1 == 0)
{
echo "<script>alert(' Check your UserName. No such Data Exists  ');</script>";
echo "<script>location.href='forgot.php?err=Invalid Username';</script>";
}
else
{
$random=mt_rand(100000,999999);


/*New Script of Phpmailer*/
$to_name = "Newbee";
$to = "$uname";


$subject = "New generated password from Trihari Smart Solutions";

$message = "Your New Password is:".$random;
$message = wordwrap($message, 70);


$from_name = "admin";
$from = "info@triharisolutions.com";


$mail = new PHPMailer();

$mail->IsSMTP();
$mail->SMTPDebug  = 2;
$mail->Host = "webmail.triharisolutions.com";
$mail->Port = 25;
$mail->SMTPAuth = true;
$mail->Username = "info@triharisolutions.com";
$mail->Password = "info@trihari@1234";


$mail->FromName = $from_name;
$mail->From = $from;
$mail->AddAddress($to, $to_name);
$mail->Subject = $subject;
$mail->Body = $message;

$result = $mail->Send();
header('location:forgot.php');
}
?>