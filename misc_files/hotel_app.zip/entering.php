<?php
include("db.php");
require_once('/phpmail/class.phpmailer.php');
require_once('/phpmail/class.smtp.php');
$name=trim($_POST['username1']);
$sql="select * from users where username='$name'";
$result=mysql_query($sql,$con);
$num_rows=mysql_num_rows($result);
if($num_rows != 0)
{
echo "<script>alert(' UserName already Exist Log In if Account Already Have ');</script>";
echo "<script>location.href='signup.php';</script>";
}
else
{
$pass=trim($_POST['password1']);
$insert="INSERT INTO users(username,password) VALUES('$name','$pass')";
$result=mysql_query($insert);
$message="  											
<html>
<head></head>
<body>
<div style=' padding-left:75px; padding-right:75px; width:auto; height:auto;'>
<div style='display:block; padding-left:35px; padding-right:35px; position:relative; padding-top:25px; padding-bottom:25px; width:auto; height:300px;  border: 1px hidden #FFD735; background-color:#ffffff; border-radius:5px;'>
<center><font style='color:#C41200; font-size:21px; font-weight:bolder; '><u> Dovato Log In Information </u></font></center><br>
<font style='color:#000000; font-size:14px; text-align:justify; '>Dear User, <br>&nbsp;&nbsp; We are happy to know that you have shown keen interest in our site.<br> Your Username :  <font style=' font-weight:bold'> ".$name."</font><br> Your Password : <font style=' font-weight:bold'> ".$pass."</font><br> Click on the Below Link to Continue your Experience with Dovato <br></font>
<form name='details4' method='post' action='update.php' target='_blank'>
<center>
<input type='hidden' name='hid2' value='".$name."'>
<input type='button' name='submit' value='Verify' style='background-color:#498AF3; text-align:center; color:#ffffff; font-family:Lucia Grande; font-size:14px; cursor:pointer; font-weight:bolder; border-radius:2px; border:1px hidden #000000; height:30px; width:auto;'>
</center>
</form>
<br>
</div>
</div>
</body>
</html>";
/*New Script of Phpmailer*/
$to_name = "Newbee";
$to = "$name";


$subject = "Mail test at ";

$message = "Welcome to Trihari Smart Solutions, Please send a reply mail to confirm your signup";
$message = wordwrap($message, 70);


$from_name = "admin";
$from = "info@triharisolutions.com";


$mail = new PHPMailer();

$mail->IsSMTP();
$mail->SMTPDebug  = 2;
$mail->Host = "webmail.triharisolutions.com";
$mail->Port = 25;
$mail->SMTPAuth = true;
$mail->Username = "info@triharisolutions.com";
$mail->Password = "info@trihari@1234";


$mail->FromName = $from_name;
$mail->From = $from;
$mail->AddAddress($to, $to_name);
$mail->Subject = $subject;
$mail->Body = $message;

$result = $mail->Send();

//echo $result ? 'Sent' : 'Error';



/*New Script of Phpmailer End*/


//$mail->Username = "info@triharisolutions.com";

//$headers  = 'MIME-Version: 1.0' . "\r\n";
//$headers .= 'Content-type: text/html; charset=iso-8859-1' . "\r\n";
//mail("$name"," New Account Acknowledgement ",$message,$headers);
}
if($result)
{
echo "<script> alert (' Click on the Link sent to your Mail Id to Continue with Us '); </script>";
echo "<script>location.href='login.php';</script>";
}
else
die('Could not connect: ' . mysql_error());
?>