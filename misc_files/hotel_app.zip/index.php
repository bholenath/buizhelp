<?php
include("header.php");
?>
<hr width="100%" style="height:1;"></hr>
<div style="visibility:visible; position:relative; padding-left:10px; padding-right:8px; width:auto; height:auto;">
<div style="width:auto; height:152px; position:relative; padding:'0' '0' '0' '0'; border: 0 hidden #FFFFFF; ">
<div id="account" style="width:56%; position:relative; float:left; height:150px; padding-top:7px; padding-left:8px; padding-right:8px; border: 1px solid #FFD735; border-radius:5px;">
<font style="font-family:Arial Black;  font-size:21px; color:#C41200; ">Domato is a Good way To find Local Businesses</font>
<br>
<label style="display:block; position:relative; float:left; padding-top:10px;"> 
<font style="font-family:arial; font-size:17px; text-align:justify; color:#000000; ">People use Domato to search for everything from the city's 
tastiest burger to the most renowned cardiologist. What will you uncover in your neighborhood?</font>
</label>
<br>
<label style="display:block; position:relative; float:left; padding-top:10px;">
<form  method="post" action="signup.php" name="frm2" id="frm2" target="_blank" >
<input type="submit" class="button" name="free" value="Create Your Free Account" style="background-color:#00A9FF; cursor:pointer; color:#FFFFFF; 
font-family:Arial; font-size:18px; font-weight:bolder; border-radius:2px; border:1px hidden #000000; height:33px; width:auto;">
</form>
</label> 
</div>
<label style=" display:block; position:relative; float:left; width:0.8%; visibility:hidden; font-family:Lucia Grande; font-size:18px; height:25px; font-weight:bolder; background-color:#D7D7D7; border:1px hidden #000000; border-radius:2px;">
</label>
<div id="ads" style="width:39.9%; position:relative; float:left; height:150px; padding-top:7px; padding-left:6px; padding-right:6px; 
border: 1px solid #DEDEDA; border-radius:5px; background-color:#EEEEEE;">
<label style=" display:block; width:auto; position:relative; font-family:Arial; font-size:21px; height:inherit; text-align:center; 
color:#C41200; font-weight:bolder; background-color:inherit; border:1px hidden #000000;">
Get <font size="+3">5-10%</font> Discount on your favourite destinations<br> Just Log in from our site and avail great Offers<br>
<center><font size="+2">Hurry Now! Limited Offer</font></center>
</label>
</div>
</div>
<br>
<label style=" float:left; position:relative; padding-left:auto; padding-top:6px;">
<font style="font-family:Arial ; font-weight:bold; font-size:21px; color:#C41200; ">Best Of Domato : Dehradun</font>
</label>
<br><br>
<div style="width:auto; height:360px; position:relative; padding:'0' '0' '0' '0'; border: 0 hidden #FFFFFF; ">
<div id="account" style="width:65%; float:left; position:relative; height:361.5px; border: 1px solid #E5E5E5; padding-top:0;
padding-left:0; padding-bottom:0; border-radius:5px; background-color:#FFFFFF;">
<ul id="menu" style="list-style:none; margin-left:0; margin-top:0; margin-bottom:0; display:block; position:relative; float:left;
width:auto; padding-top:0; padding-left:0; padding-bottom:0; height:auto; white-space:nowrap;  font-weight:bold; 
text-align:left; font-family:Times New Roman; font-size:13px; color:#000000;">
<li id="home" style="display:inline-block; text-align:center; width:160px; border:1px solid #E5E5E5; border-top-style:hidden; border-bottom-style:hidden; clear:left; padding-top:0; float:left;">
<font style="color:#3B65A7;">Restaurants</font><br><font style="font-family:Times New Roman; font-weight:500; font-size:11px; color:#D1D1D1;">reviewed</font></li>
<li id="home" style="display:inline-block; text-align:center; width:160px; border:1px solid #E5E5E5; border-bottom-style:hidden; clear:left; padding-top:0; float:left;">
<font style="color:#3B65A7;">Hotel & Travel</font><br><font style="font-family:Times New Roman; font-weight:500; font-size:11px; color:#D1D1D1; ">reviewed</font></li>
<li id="home" style="display:inline-block; text-align:center; width:160px; border:1px solid #E5E5E5; border-bottom-style:hidden; clear:left; padding-top:0; float:left;">
<font style="color:#3B65A7;">Shopping</font><br><font style="font-family:Times New Roman; font-weight:500; font-size:11px; color:#D1D1D1; ">reviewed</font></li>
<li id="home" style="display:inline-block; text-align:center; width:160px; border:1px solid #E5E5E5; border-bottom-style:hidden; clear:left; padding-top:0; float:left;">
<font style="color:#3B65A7;">Bars</font><br><font style="font-family:Times New Roman; font-weight:500; font-size:11px; color:#D1D1D1; ">reviewed</font></li>
<li id="home" style="display:inline-block; text-align:center; width:160px; border:1px solid #E5E5E5; border-bottom-style:hidden; clear:left; padding-top:0; float:left;">
<font style="color:#3B65A7;">Breakfast & Brunch</font><br><font style="font-family:Times New Roman; font-weight:500; font-size:11px; color:#D1D1D1; ">reviewed</font></li>
<li id="home" style="display:inline-block; text-align:center; width:160px; border:1px solid #E5E5E5; border-bottom-style:hidden; clear:left; padding-top:0; float:left;">
<font style="color:#3B65A7;">Health & Medical</font><br><font style="font-family:Times New Roman; font-weight:500; font-size:11px; color:#D1D1D1; ">reviewed</font></li>
<li id="home" style="display:inline-block; text-align:center; width:160px; border:1px solid #E5E5E5; border-bottom-style:hidden; clear:left; padding-top:0; float:left;">
<font style="color:#3B65A7;">Local Services</font><br><font style="font-family:Times New Roman; font-weight:500; font-size:11px; color:#D1D1D1; ">reviewed</font></li>
<li id="home" style="display:inline-block; text-align:center; width:160px; border:1px solid #E5E5E5; border-bottom-style:hidden; clear:left; padding-top:0; float:left;">
<font style="color:#3B65A7;">Automotive</font><br><font style="font-family:Times New Roman; font-weight:500; font-size:11px; color:#D1D1D1; ">reviewed</font></li>
<li id="home" style="display:inline-block; text-align:center; width:160px; border:1px solid #E5E5E5; border-bottom-style:hidden; clear:left; padding-top:0; float:left;">
<font style="color:#3B65A7;">Beauty & Spas</font><br><font style="font-family:Times New Roman; font-weight:500; font-size:11px; color:#D1D1D1; ">reviewed</font></li>
<li id="home" style="display:inline-block; text-align:center; width:160px; border:1px solid #E5E5E5; border-bottom-style:hidden;  clear:left; padding-top:0; float:left;">
<font style="color:#3B65A7;">Arts & Entertainement</font><br><font style="font-family:Times New Roman; font-weight:500; font-size:11px; color:#D1D1D1; ">reviewed</font></li>
<li id="home" style="display:inline-block; text-align:center; width:160px; border:1px solid #E5E5E5; border-bottom-style:hidden;  clear:left; padding-top:0; float:left;">
<font style="color:#3B65A7;">Education</font><br><font style="font-family:Times New Roman; font-weight:500; font-size:11px; color:#D1D1D1; ">reviewed</font></li>
</ul>
</div>
<label style=" display:block; position:relative; float:left; width:0.8%; visibility:hidden; font-family:Lucia Grande; font-size:18px; height:25px; font-weight:bolder; background-color:#D7D7D7; border:1px hidden #000000; border-radius:2px;">
</label>
<div id="account" style="width:33%; float:left; position:relative; height:358.8px; border: 1px solid #E5E5E5; padding-top:1.9px; padding-left:0; padding-bottom:0; border-radius:5px; background-color:#FFFFFF;">
<label style=" display:block; position:relative; width:auto; font-family:Arial; font-size:16px; height:41%; text-align:left; color:#C41200; 
padding-left:10px; padding-right:10px; padding-bottom:5px;  font-weight:bold; background-color:inherit; border:1px hidden #000000;">
Reviews
</label>
<center><hr width="90%" style="height:1px; "></hr></center>
<label style=" display:block; width:auto; position:relative; font-family:Arial; font-size:16px; height:50%; text-align:left; color:#C41200; padding-top:0;
padding-left:10px; padding-right:10px; font-weight:bold; background-color:inherit; border:1px hidden #000000;">
Space for Advertisements
<label style=" display:block; position:relative; width:auto; font-family:Arial; font-size:16px; height:auto; text-align:left; color:#C41200; 
padding-left:10px; padding-right:10px; padding-top:18px; font-weight:bold; background-color:inherit; border:1px hidden #000000;">
<img src="logo7.png">
</label>
</label>
</div>
</div>
</div>
<hr width="100%" style="height:1;"></hr>
<?php
include("footer.php");
?>