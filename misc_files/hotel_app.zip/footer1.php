<div id="footer" style="width:99%; height:47px; font-size:13px; font-family:Times New Roman; padding-left:10px; position:absolute; bottom:0;
border-top-style:hidden; border-radius:2px;background-image:url(header_stars.png); background-repeat:repeat-x; background-color:#00A9FF;">
<div style="height:15px; width:100%; background-color:#00A9FF "></div>
<label style="float:left;"><b><i>Copyright &copy; <?php echo date('Y');?> | All Rights Reserved |
<a href="main.php" target="_blank">Datavo</a><b><i></label>
<label style=" display:block; float:left; width:7%; visibility:hidden; font-family:Lucia Grande; font-size:18px; height:25px; font-weight:bolder; 
background-color:#D7D7D7; border:1px hidden #000000; border-radius:2px;">
</label>
<label style="float:left;"><b> Join us on </b></label>
<label style="float:right;   padding-right:33px;"><b><i>Powered By &nbsp;<a href="http://triharismartsolutions.com/" 
target="_blank">Trihari Smart Solutions<b><i></label>
</div>
</body>
</html>